Homework 2 - q10_4_2_README.txt
Program: Computation to MMD 10.4.2

=== Files Includes For This Program ===

    q10_4_2_README.txt
    q10_4_2.py

=== How Do The Programs Work ===
    Generate adjacent matrix, degree matrix and Laplacian matrix. Eigen-decomposite the Laplacian matrix to obtain the second smallest and third smallest eigenvalues (which are close to each other), and their corresponding eigenvectors.